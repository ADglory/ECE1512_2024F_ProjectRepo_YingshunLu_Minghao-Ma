    The code of "Prioritize Alignment in Dataset Distillation" can be found at https://github.com/NUS-HPC-AI-Lab/DATM?tab=readme-ov-file, which
is created by the author of this paper. You can download it and run it according to the instructions

    However, the author doesn't provide the files to deal with MNIST dataset in his/her code. So we provide you with the modified "utils" files
and an yaml file to help you deal with it. Hope you can go well with them.